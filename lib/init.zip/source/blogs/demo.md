Title: 测试文件 - SOLO 2.0
Date: 2013-02-27 13:25:36
Tags: 测试 markdown solo

这是一篇用来测试TooSolo 2.0的文章。

## Markdown

TooSolo使用Markdown语法进行写作，你可以选用任何编辑器进行编写：

- Mou
- MarkdownPad
- Made
- And so on ...

还可以标记“更多”哦……

<!-- $$solo_more$$ -->

这里的内容只在文章中才会出现啦，是不是很方便呢？