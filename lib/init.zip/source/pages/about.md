Title: SOLO 简介
Date: 2013-02-27 13:25:36

## solo 是一个由Node构建的静态博客

- 这个静态博客是用markdown来写文章，通过皮肤模板可以build出html页面。
- 你可以将他提交至Github Pages等任何网站空间。
- 示例:<http://solo.toobug.net>

## 2.0 预览版特性

- 程序、源文件、构建结果完全分离，托管时只需要上传构建结果即可
- 全插件构架，可以任意扩展你需要的功能（标签、分类、RSS等等）

